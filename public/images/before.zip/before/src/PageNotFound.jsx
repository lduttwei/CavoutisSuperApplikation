import React from "react";

export default function PageNotFound() {
  return <h1>Page not found.</h1>;
}
